mysqldump -uroot -ptoot wordpress
