mysqldump -uroot -p wordpress
